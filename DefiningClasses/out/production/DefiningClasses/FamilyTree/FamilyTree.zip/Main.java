package FamilyTree;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;


public class Main {
    public static Person person = new Person();
    public static ArrayList<Person> people = new ArrayList<Person>();
    public static LinkedHashMap<String, Person> map = new LinkedHashMap<>();
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<Person> parents = new ArrayList<>();
        ArrayList<Person> children = new ArrayList<>();
        String input = br.readLine();
        boolean firstParent = false;
        if(input.contains("/")){
            person.setBirthday(input);
        }
        else{
            person.setName(input);
        }

        StringBuilder sb = new StringBuilder();
        while(true){
            String toAppend = br.readLine();
            sb.append(toAppend).append("\n");
            if(toAppend.equals("End")){
                break;
            }
        }
        findPerson(sb.toString().split("\\n"));
        findPeople(sb.toString().split("\\n"));
        int i=0;
        String[] commands = sb.toString().split("\\n");
        while(true){
            String line = commands[i++];
            if(line.equals("End")){
                break;
            }
            int form = getForm(line);
            switch(form){
                case 1: {
                    String[] split = line.split(" - ");
                    Person child = new Person();
                    Person parent = new Person();
                    child.setName(split[1]);
                    parent.setName(split[0]);
                    if(child.getName().equals(person.getName())) {
                        parents.add(parent);
                    }
                    if(person.getName().equals(parent.getName())) {
                        children.add(child);
                    }
                    break;
                }
                case 2: {
                    String[] split = line.split(" - ");
                    Person child = new Person();
                    Person parent = new Person();
                    parent.setName(split[0]);
                    child.setBirthday(split[1]);
                    if(child.getBirthday().equals(person.getBirthday())) {
                        parents.add(parent);
                    }
                    if(person.getName().equals(parent.getName())) {
                        children.add(child);
                    }
                    break;
                }
                case 3: {
                    String[] split = line.split(" - ");
                    Person child = new Person();
                    Person parent = new Person();
                    parent.setBirthday(split[0]);
                    child.setName(split[1]);
                    if(child.getName().equals(person.getName())) {
                        parents.add(parent);
                    }
                    if(person.getBirthday().equals(parent.getBirthday())){
                        children.add(child);
                    }
                    break;
                }
                case 4: {
                    String[] split = line.split(" - ");
                    Person child = new Person();
                    Person parent = new Person();
                    child.setBirthday(split[1]);
                    parent.setBirthday(split[0]);
                    if(child.getBirthday().equals(person.getBirthday())) {
                        parents.add(parent);
                    }
                    if(person.getBirthday().equals(parent.getBirthday())) {
                        children.add(child);
                    }
                    break;
                }
                case 5: {
                    String[] split = line.split("\\s");
                    if(person.getBirthday().equals(split[2]) || person.getName().equals(split[0] +" "+ split[1])){
                        person.setBirthday(split[2]);
                        person.setName(split[0] +" "+  split[1]);
                        break;
                    }
                    for(Person p: parents){
                        if(p.getName().equals(split[0] +" " + split[1]) || p.getBirthday().equals(split[2])){
                            p.setName(split[0] +" "+  split[1]);
                            p.setBirthday(split[2]);
                            break;
                        }
                    }
                    for(Person p: children){
                        if(p.getName().equals(split[0] + " " + split[1]) || p.getBirthday().equals(split[2])){
                            p.setName(split[0] +" "+  split[1]);
                            p.setBirthday(split[2]);
                            break;
                        }
                    }
                    break;
                }



            }
        }
        reformat(children);
        reformat(parents);

        System.out.println(person);
        System.out.println("Parents:");
        for(Person p: parents){
            System.out.println(p);
        }
        System.out.println("Children:");
        for(Person p: children){
            System.out.println(p);
        }

    }

    public static void findPeople(String[] array){
        for(String line: array){
            if(!line.contains("-") && !line.equals("End")){
                String[] p = line.split(" ");
                Person personNew = new Person();
                personNew.setName(p[0] + " " + p[1]);
                personNew.setBirthday(p[2]);
                people.add(personNew);
                map.put(personNew.getName(), personNew);
            }
        }
    }


    public static void findPerson(String[] array){
        for(String line: array){
            if(line.contains(person.getName()) && !line.contains("-") || line.contains(person.getBirthday()) && !line.contains("-")){
                String[] p = line.split(" ");
                person.setName(p[0] + " " + p[1]);
                person.setBirthday(p[2]);
                return;
            }
        }
    }



   public static void reformat(ArrayList<Person> list){
        ArrayList<Person> toRemove = new ArrayList<>();
        for(Person p: list){
            if(p.getName().equals(person.getName()) || p.getBirthday().equals(person.getBirthday())){
                toRemove.add(p);
            }
        }
        list.removeAll(toRemove);
   }

    public static int getForm(String input){
        if(!input.contains("-")){
            return 5;
        }
        String[] split = input.split(" - ");
        if(split[0].contains("/") && split[1].contains("/")){
            return 4;
        }
        else if(split[0].contains("/") && !split[1].contains("/")){
            return 3;
        }
        else if(!split[0].contains("/") && split[1].contains("/")){
            return 2;
        }
        return 1;



    }
}
