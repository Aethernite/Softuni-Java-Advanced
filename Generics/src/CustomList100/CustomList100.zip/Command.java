package CustomList100;

public enum Command {
    Add, Remove, Contains, Swap, Greater, Max, Min, Print, Sort
}