import spaceStationRecruitment.Astronaut;
import spaceStationRecruitment.SpaceStation;

public class Main {
    public static void main(String[] args) {
     }
}
